package de.droidenschmiede.weather.billing;

public enum DonateState {

    CHECKING, CONFIRMED, DENIED
}
